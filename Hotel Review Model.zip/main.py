import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import review, filter
# Step 1: Load the dataset
data = pd.read_csv('dataset.csv', encoding='ISO-8859-1')


# Step 2: Preprocessing
# Mapping textual responses to numerical values for each question
rating_map = {
    'strongly agree': 5,
    'agree': 4,
    'neutral': 3,
    'disagree': 2,
    'strongly disagree': 1
}

# Convert all responses to lowercase to match the rating_map keys
for col in data.columns[3:17]:  # Assuming Q1 starts from the 4th column and goes up to Q13
    data[col] = data[col].str.lower()  # Convert responses to lowercase
    data[col] = data[col].map(rating_map)  # Apply the mapping

# Step 3: Calculate an average rating as the overall rating
data['Overall Rating'] = data.iloc[:, 3:17].mean(axis=1)

# Strip leading/trailing spaces from column names
data.columns = data.columns.str.strip()

# Step 4: Creating Features and Target Variable
X = data.drop(columns=['Hotel Name', 'Location', 'Country', 'Overall Rating', 'Q14. You will recommend this hotel facility to your friends.'])  # Features
y = data['Overall Rating']  # Target (calculated overall rating)

# Step 5: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Train the model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Step 7: Model Evaluation
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse}")

# Step 8: Generate Overall Rating for New Data
def predict_overall_rating(input_data):
    prediction = model.predict([input_data])
    return round(prediction[0], 2)


# Check if NaNs are present in sample_data
print(X_test.iloc[0])

# Step 10: Example Usage
# Get the index of the sample data
sample_index = X_test.index[0]  # Index of the first row in X_test

# Extract the full row from the original data DataFrame
full_sample_data = data.loc[sample_index]

# Extract features from the sample data
sample_features = X_test.iloc[0]

# Predict the overall rating
predicted_rating = predict_overall_rating(sample_features)

# Generate a detailed review
brief_review = review.generate_verbose_review(full_sample_data.to_dict())

print(f"Predicted Overall Rating: {predicted_rating} stars")
print(f"Brief Review: {brief_review}")

