
def filter_data(dataframe):
    """
    Filters the dataset to ensure all text is valid UTF-8 and replaces non-UTF-8 characters with None.
    Also fills NaN values with the mean of their respective columns for numerical data.
    
    Args:
        dataframe (pd.DataFrame): The input DataFrame to be cleaned.
        
    Returns:
        pd.DataFrame: The cleaned DataFrame.
    """
    # Convert all columns to string type to handle any non-UTF-8 characters
    dataframe = dataframe.map(lambda x: x.encode('utf-8', 'ignore').decode('utf-8') if isinstance(x, str) else x)

    # Replace any remaining non-UTF-8 characters with None
    dataframe.replace('', None, inplace=True)

    # Fill NaN values with the mean of their respective columns for numerical data
    for column in dataframe.select_dtypes(include=['float64', 'int64']).columns:
        dataframe[column].fillna(dataframe[column].mean(), inplace=True)

    return dataframe
